self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7512165003f95e243ab2c65acbe151e4",
    "url": "/admin.html"
  },
  {
    "revision": "1bc7b654b1d77509ded99981c3eea722",
    "url": "/app.html"
  },
  {
    "revision": "1cf9c68085a5aa0427a0e87f952fb742",
    "url": "/auth.html"
  },
  {
    "revision": "5d5c07f511a191868835df8119185f42",
    "url": "/img/Archive.png"
  },
  {
    "revision": "9703baaed76cd7b86834037b0b1d9a29",
    "url": "/img/Archive@2x.png"
  },
  {
    "revision": "3403e43d15879af29b66cf06d578c5f9",
    "url": "/img/Autosave.png"
  },
  {
    "revision": "6e8061919cc2f38989edb8fd4442d27a",
    "url": "/img/Autosave@2x.png"
  },
  {
    "revision": "63327f5bfb928af6bd432968838b2cd9",
    "url": "/img/Data.png"
  },
  {
    "revision": "cc8f6d4384634d0f0122e662ee9ba25f",
    "url": "/img/Data@2x.png"
  },
  {
    "revision": "525f5cb658c71859b6012cc9054c15fa",
    "url": "/img/Dictionary.png"
  },
  {
    "revision": "2a48829415c20e45208e95dc28f7ee8b",
    "url": "/img/Dictionary@2x.png"
  },
  {
    "revision": "56837a2db27bc536891f5b9174ba4afb",
    "url": "/img/Hero-spots.png"
  },
  {
    "revision": "d37b38c5c09c9c578ffbced0d723d30e",
    "url": "/img/Hero-spots@2x.png"
  },
  {
    "revision": "f58c2c17884ec34513a76098ccab514b",
    "url": "/img/Hero-tablet-01.png"
  },
  {
    "revision": "413e787b74c919854d4fc285154782c0",
    "url": "/img/Hero-tablet-01@2x.png"
  },
  {
    "revision": "144b43af4287941f6f9c4ad1efe57134",
    "url": "/img/Interactive-map.png"
  },
  {
    "revision": "aeb1bbd4a5954bd9b0bb4c7358caff17",
    "url": "/img/Interactive-map@2x.png"
  },
  {
    "revision": "06ed376086bf98a485125bc71e7a5442",
    "url": "/img/Log-in.png"
  },
  {
    "revision": "da95982353ea6da5675e6ffd18d92767",
    "url": "/img/Log-in@2x.png"
  },
  {
    "revision": "c48182459a0a6fa9525d10bff6e09c32",
    "url": "/img/Outline.png"
  },
  {
    "revision": "ff69eec62856634b21788e2804568870",
    "url": "/img/Outline@2x.png"
  },
  {
    "revision": "5e0e5a30b2af795f0b0bef4f2f5e1372",
    "url": "/img/Pdf.png"
  },
  {
    "revision": "fd14371678ff9f00fde7da24428f29e9",
    "url": "/img/Pdf@2x.png"
  },
  {
    "revision": "59770374d53faebb0e53d2968e8115ff",
    "url": "/img/Search.png"
  },
  {
    "revision": "5669edeaff1d6510179e99ecc98341d1",
    "url": "/img/Search@2x.png"
  },
  {
    "revision": "6899968cf7139f35f5dd7ac55c0a0ba4",
    "url": "/img/Upload.png"
  },
  {
    "revision": "4de4847b196fb7649ce01a7a0fac3ffa",
    "url": "/img/Upload@2x.png"
  },
  {
    "revision": "5b33ae66bbe11595b84886df47afb5f9",
    "url": "/img/Web 1920 – App Write (Plan).png"
  },
  {
    "revision": "bba84f056c14db459e169fc1ab08fa20",
    "url": "/img/edward-favicon_120.png"
  },
  {
    "revision": "c0d72ab6bcfc1b3caa9566cc52a90537",
    "url": "/img/edward-favicon_128.png"
  },
  {
    "revision": "9050f3e0a2c3462b5948442839a5bee4",
    "url": "/img/edward-favicon_144.png"
  },
  {
    "revision": "8203805043df482c5cf3501004376128",
    "url": "/img/edward-favicon_152.png"
  },
  {
    "revision": "fc7754c2cffd4c0580199077eb25466b",
    "url": "/img/edward-favicon_16.png"
  },
  {
    "revision": "0d0630253389e75a4016837bf6ed67a8",
    "url": "/img/edward-favicon_180.png"
  },
  {
    "revision": "c97c842626aa8004ea14b451463d1d4e",
    "url": "/img/edward-favicon_192.png"
  },
  {
    "revision": "2619811d0f651bbe237ee06a668d960a",
    "url": "/img/edward-favicon_195.png"
  },
  {
    "revision": "0323f283efc26befbcfcb0054587a026",
    "url": "/img/edward-favicon_196.png"
  },
  {
    "revision": "488cff5913f7fdf7997d728428f4819c",
    "url": "/img/edward-favicon_32.png"
  },
  {
    "revision": "d3a3110108c128e66195dfb234231e6b",
    "url": "/img/edward-favicon_512.png"
  },
  {
    "revision": "d2df27bfad1e9d8751e1f9345e13fced",
    "url": "/img/edward-favicon_57.png"
  },
  {
    "revision": "a297a4eb6ad4fc7cbdb06e25ee1f4c72",
    "url": "/img/edward-favicon_76.png"
  },
  {
    "revision": "d8ac621e2cbd03b5fbb576a58b896c99",
    "url": "/img/edward-favicon_96.png"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/img/form-logo.png"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/img/form-logo@2x.png"
  },
  {
    "revision": "afd46f727eebae460a2c8b361c184488",
    "url": "/img/icons_account-white.png"
  },
  {
    "revision": "bdf552ee629d4e4e4aac384ef0faf65a",
    "url": "/img/icons_more-white.png"
  },
  {
    "revision": "a62c7a35795181a79b34a5e5de431472",
    "url": "/img/icons_outline-green.png"
  },
  {
    "revision": "c0516e1bb9887e56d46e5bed4b91ba4a",
    "url": "/img/icons_outline-white.png"
  },
  {
    "revision": "a323336767255ff753a2a4eb391f4489",
    "url": "/img/icons_plan-green.png"
  },
  {
    "revision": "348eb416472eef84d69425025c480380",
    "url": "/img/icons_plan-white.png"
  },
  {
    "revision": "15aedca4d4c98a24c1c9aa7d7211a832",
    "url": "/img/icons_workshops-green.png"
  },
  {
    "revision": "ec282b2e0e4ad2e1fc97e533734b8177",
    "url": "/img/icons_write-white.png"
  },
  {
    "revision": "b18d4df3d403e78c2bfe4dd9c77bd38e",
    "url": "/img/main-logo.png"
  },
  {
    "revision": "e67e1e98d29daf715fe7977dc4ee2ebc",
    "url": "/img/main-logo@2x.png"
  },
  {
    "revision": "937da8d3137ec4f44587b82627285479",
    "url": "/img/mobile-logo.png"
  },
  {
    "revision": "cc738e32a4d8ca9f0f629306e307ea61",
    "url": "/img/mobile-logo@2x.png"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/img/modal-logo.png"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/img/modal-logo@2x.png"
  },
  {
    "revision": "825d1ef2f0a157c855e55c3fe65dd694",
    "url": "/img/old/Book-2.svg"
  },
  {
    "revision": "d7a54a779bf7352026e053db7aefd8c6",
    "url": "/img/old/Books.svg"
  },
  {
    "revision": "7976fee44571aab5896eaee85a18be65",
    "url": "/img/old/Checklist.svg"
  },
  {
    "revision": "63807be15f786db6df752c8f63188137",
    "url": "/img/old/Data-Transfer.svg"
  },
  {
    "revision": "a92162e1e6b0aeb009322f7402470012",
    "url": "/img/old/Download-Book.svg"
  },
  {
    "revision": "3ffdaff217b171b32ea2425fe4e59b8c",
    "url": "/img/old/Floppy-Disk.svg"
  },
  {
    "revision": "2d81f1deb2b49c4df263e0c8d33c1136",
    "url": "/img/old/Folder.svg"
  },
  {
    "revision": "2ae233190f674f5bfc9cde5ae06113b0",
    "url": "/img/old/Globe.svg"
  },
  {
    "revision": "8c15a975ae07355603340c287f3a4d51",
    "url": "/img/old/Magnifier.svg"
  },
  {
    "revision": "6a1e19199fe88319dc6e8dd865047336",
    "url": "/img/old/Map.svg"
  },
  {
    "revision": "13c791a68db71393999f93269aba1386",
    "url": "/img/old/Tablet-Chart.svg"
  },
  {
    "revision": "b9f4a8e6f3d1c3aaeaf2899d616ab989",
    "url": "/img/old/Time-Burn.svg"
  },
  {
    "revision": "c5f97cb1b8b890059013821412cedf0c",
    "url": "/img/old/app-screenshot.png"
  },
  {
    "revision": "eaf13b721f837da0843767159cca72ad",
    "url": "/img/old/edward-analyze.png"
  },
  {
    "revision": "3bdd4172f514066c84885a124dadeeac",
    "url": "/img/old/edward-outlines.png"
  },
  {
    "revision": "ccdad086da02c10eb2a4154ed6e34dcf",
    "url": "/img/old/edward-plans.png"
  },
  {
    "revision": "46c79677df0ee7d8c4e1ba88e412001d",
    "url": "/img/old/favicon-144x144.png"
  },
  {
    "revision": "cc7ef9a9ff24f6ab32c76c44808d8c81",
    "url": "/img/old/favicon-152x152.png"
  },
  {
    "revision": "eb79418117a636f5899ab1d7b642a780",
    "url": "/img/old/favicon-16x16.png"
  },
  {
    "revision": "02cd07ba0d732c582f85ac8c364779d3",
    "url": "/img/old/favicon-32x32.png"
  },
  {
    "revision": "d197d194ff350fc53077dc5f9dba7cb2",
    "url": "/img/old/favicon-64x64.png"
  },
  {
    "revision": "6969d59d900aaf7d1f27215635b75bff",
    "url": "/img/old/favicon.png"
  },
  {
    "revision": "2151149934d0b229e918aa50a8dd9f4e",
    "url": "/img/old/favicon.svg"
  },
  {
    "revision": "f4aa04ce66b1198251e19c81ac511605",
    "url": "/img/old/icon-192.png"
  },
  {
    "revision": "0d7e90660ca646efac9f547cdf834a14",
    "url": "/img/old/icon-512.png"
  },
  {
    "revision": "fde809d329a958ee509f41a858898363",
    "url": "/img/old/icon-small.png"
  },
  {
    "revision": "604a4bc084d9d346f61316eea852777b",
    "url": "/img/old/logo.png"
  },
  {
    "revision": "5da22d927f509a1d6e0c7e9bc69b06bc",
    "url": "/img/old/logo.svg"
  },
  {
    "revision": "7e8135710c3693c36f00ee8a4cf09091",
    "url": "/img/old/wizard-screenshot.PNG"
  },
  {
    "revision": "3d31edda2822efc0da5a8d81d6e0cd06",
    "url": "/img/old/word-processor.png"
  },
  {
    "revision": "5d8705a0764f70c89fbd5cd512cf32ce",
    "url": "/img/twitter-header.png"
  },
  {
    "revision": "4acde976ff6f2975475347d90fe02929",
    "url": "/index-old.css"
  },
  {
    "revision": "e934c7949d5a28e4f2e492a2837b3c7d",
    "url": "/index-old.html"
  },
  {
    "revision": "aff6df852be996384b09807a3e37c553",
    "url": "/index.css"
  },
  {
    "revision": "0e0b08a61f6703902b4be0239ae0c3f0",
    "url": "/index.html"
  },
  {
    "revision": "4733cfdca315833a93f8f2b8f52520ca",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "592bdae3e8d842384ac7",
    "url": "/static/css/account-page.2faa39e5.css"
  },
  {
    "revision": "e2c3d6f8282213a2e8bb",
    "url": "/static/css/admin.a62e0f55.css"
  },
  {
    "revision": "9758081a5ac7313d2c5d",
    "url": "/static/css/analyser.e777c0a2.css"
  },
  {
    "revision": "5bf7dba8600bb41ad948",
    "url": "/static/css/app.5d902150.css"
  },
  {
    "revision": "aab78c5f161fd0e278f5",
    "url": "/static/css/auth.3be9293b.css"
  },
  {
    "revision": "42147f9c2b77eb926daf",
    "url": "/static/css/chunk-vendors.d78f29d5.css"
  },
  {
    "revision": "37b6e53111d483d97f06",
    "url": "/static/css/exporter.da28a4fd.css"
  },
  {
    "revision": "e76bfe40ba5fe504b5b7",
    "url": "/static/css/w-free-write.cf797f0f.css"
  },
  {
    "revision": "ebf1d4e503eda61e97ff",
    "url": "/static/css/w-novel-quickstart.474aebfb.css"
  },
  {
    "revision": "75e447b3804c0f34b943",
    "url": "/static/css/w-plot-workshop.1f6b3f4b.css"
  },
  {
    "revision": "3a4f89431bee70e7ba2c",
    "url": "/static/css/w-setting-workshop.bb1f4443.css"
  },
  {
    "revision": "7f9da6147e151b571df7",
    "url": "/static/css/w-writers-unblock.cd0b4b56.css"
  },
  {
    "revision": "0323f283efc26befbcfcb0054587a026",
    "url": "/static/img/edward-favicon_196.0323f283.png"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/static/img/modal-logo.99cae3a0.png"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/static/img/modal-logo@2x.a7ee511e.png"
  },
  {
    "revision": "592bdae3e8d842384ac7",
    "url": "/static/js/account-page.3fc97df6.js"
  },
  {
    "revision": "e2c3d6f8282213a2e8bb",
    "url": "/static/js/admin.e73b7a43.js"
  },
  {
    "revision": "9758081a5ac7313d2c5d",
    "url": "/static/js/analyser.15f87b18.js"
  },
  {
    "revision": "5bf7dba8600bb41ad948",
    "url": "/static/js/app.5929d4c3.js"
  },
  {
    "revision": "aab78c5f161fd0e278f5",
    "url": "/static/js/auth.5af80792.js"
  },
  {
    "revision": "42147f9c2b77eb926daf",
    "url": "/static/js/chunk-vendors.94ba1a55.js"
  },
  {
    "revision": "37b6e53111d483d97f06",
    "url": "/static/js/exporter.7d341a41.js"
  },
  {
    "revision": "e76bfe40ba5fe504b5b7",
    "url": "/static/js/w-free-write.3c893b89.js"
  },
  {
    "revision": "ebf1d4e503eda61e97ff",
    "url": "/static/js/w-novel-quickstart.5bc1242c.js"
  },
  {
    "revision": "75e447b3804c0f34b943",
    "url": "/static/js/w-plot-workshop.dc813fe9.js"
  },
  {
    "revision": "3a4f89431bee70e7ba2c",
    "url": "/static/js/w-setting-workshop.3549b8da.js"
  },
  {
    "revision": "7f9da6147e151b571df7",
    "url": "/static/js/w-writers-unblock.27f1e8ad.js"
  }
]);