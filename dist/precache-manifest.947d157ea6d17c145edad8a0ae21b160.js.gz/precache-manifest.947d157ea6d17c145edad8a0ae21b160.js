self.__precacheManifest = [
  {
    "revision": "afd46f727eebae460a2c8b361c184488",
    "url": "/img/icons_account-white.png"
  },
  {
    "revision": "5c84704815537ec5eb87",
    "url": "/static/css/account-page.86a206ee.css"
  },
  {
    "revision": "e2f164182592ded21617",
    "url": "/static/css/admin.f9eb0f62.css"
  },
  {
    "revision": "e2f164182592ded21617",
    "url": "/static/js/admin.5f65904a.js"
  },
  {
    "revision": "6716f79c07eab42dd03c",
    "url": "/static/css/analyser.44b53cca.css"
  },
  {
    "revision": "6716f79c07eab42dd03c",
    "url": "/static/js/analyser.50d7fb4e.js"
  },
  {
    "revision": "f9abc9c599b89206c8dc",
    "url": "/static/css/app.35e5d32b.css"
  },
  {
    "revision": "f9abc9c599b89206c8dc",
    "url": "/static/js/app.058e6a1a.js"
  },
  {
    "revision": "bb122b11d11146d4331f",
    "url": "/static/css/auth.8fba9188.css"
  },
  {
    "revision": "bb122b11d11146d4331f",
    "url": "/static/js/auth.adbe03b7.js"
  },
  {
    "revision": "cc40aca4496ca34eb4b0",
    "url": "/static/css/chunk-vendors.1e58b737.css"
  },
  {
    "revision": "cc40aca4496ca34eb4b0",
    "url": "/static/js/chunk-vendors.772ca58a.js"
  },
  {
    "revision": "403d24d3eb7f0e721a03",
    "url": "/static/css/exporter.f9649b20.css"
  },
  {
    "revision": "403d24d3eb7f0e721a03",
    "url": "/static/js/exporter.f22f08e0.js"
  },
  {
    "revision": "6a3db803c032001388d0",
    "url": "/static/css/w-free-write.7697b0ba.css"
  },
  {
    "revision": "6a3db803c032001388d0",
    "url": "/static/js/w-free-write.ae3146ae.js"
  },
  {
    "revision": "e0cb61bd8c7230c821c8",
    "url": "/static/css/w-novel-quickstart.e38debc6.css"
  },
  {
    "revision": "e0cb61bd8c7230c821c8",
    "url": "/static/js/w-novel-quickstart.f846ed19.js"
  },
  {
    "revision": "a6f94de9ccd398a5d8d4",
    "url": "/static/css/w-plot-workshop.817c5a4f.css"
  },
  {
    "revision": "a6f94de9ccd398a5d8d4",
    "url": "/static/js/w-plot-workshop.eac2ab8e.js"
  },
  {
    "revision": "1dd1b90f268b7129d266",
    "url": "/static/css/w-setting-workshop.817c5a4f.css"
  },
  {
    "revision": "1dd1b90f268b7129d266",
    "url": "/static/js/w-setting-workshop.566449ca.js"
  },
  {
    "revision": "69002373e7e01780a1e1",
    "url": "/static/css/w-writers-unblock.8b4a7c0f.css"
  },
  {
    "revision": "69002373e7e01780a1e1",
    "url": "/static/js/w-writers-unblock.0ebd77fa.js"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/static/img/modal-logo.99cae3a0.png"
  },
  {
    "revision": "1a512567f75e14f71119f684ab9c3d7e",
    "url": "/static/img/edward-favicon-196.1a512567.png"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/static/img/modal-logo@2x.a7ee511e.png"
  },
  {
    "revision": "5c84704815537ec5eb87",
    "url": "/static/js/account-page.7bfb062e.js"
  },
  {
    "revision": "ec282b2e0e4ad2e1fc97e533734b8177",
    "url": "/img/icons_write-white.png"
  },
  {
    "revision": "98778cc9c151e0269553a083f851aadc",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  },
  {
    "revision": "7976fee44571aab5896eaee85a18be65",
    "url": "/img/old/Checklist.svg"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/img/modal-logo.png"
  },
  {
    "revision": "1b3f1c85fb531af0a815a1aa236ba6f1",
    "url": "/index-old.html"
  },
  {
    "revision": "5d8705a0764f70c89fbd5cd512cf32ce",
    "url": "/img/twitter-header.png"
  },
  {
    "revision": "aff6df852be996384b09807a3e37c553",
    "url": "/index.css"
  },
  {
    "revision": "4acde976ff6f2975475347d90fe02929",
    "url": "/index-old.css"
  },
  {
    "revision": "7e8135710c3693c36f00ee8a4cf09091",
    "url": "/img/old/wizard-screenshot.PNG"
  },
  {
    "revision": "3d31edda2822efc0da5a8d81d6e0cd06",
    "url": "/img/old/word-processor.png"
  },
  {
    "revision": "604a4bc084d9d346f61316eea852777b",
    "url": "/img/old/logo.png"
  },
  {
    "revision": "0d7e90660ca646efac9f547cdf834a14",
    "url": "/img/old/icon-512.png"
  },
  {
    "revision": "b9f4a8e6f3d1c3aaeaf2899d616ab989",
    "url": "/img/old/Time-Burn.svg"
  },
  {
    "revision": "6a1e19199fe88319dc6e8dd865047336",
    "url": "/img/old/Map.svg"
  },
  {
    "revision": "13c791a68db71393999f93269aba1386",
    "url": "/img/old/Tablet-Chart.svg"
  },
  {
    "revision": "8c15a975ae07355603340c287f3a4d51",
    "url": "/img/old/Magnifier.svg"
  },
  {
    "revision": "5da22d927f509a1d6e0c7e9bc69b06bc",
    "url": "/img/old/logo.svg"
  },
  {
    "revision": "6969d59d900aaf7d1f27215635b75bff",
    "url": "/img/old/favicon.png"
  },
  {
    "revision": "f4aa04ce66b1198251e19c81ac511605",
    "url": "/img/old/icon-192.png"
  },
  {
    "revision": "fde809d329a958ee509f41a858898363",
    "url": "/img/old/icon-small.png"
  },
  {
    "revision": "2d81f1deb2b49c4df263e0c8d33c1136",
    "url": "/img/old/Folder.svg"
  },
  {
    "revision": "2ae233190f674f5bfc9cde5ae06113b0",
    "url": "/img/old/Globe.svg"
  },
  {
    "revision": "3ffdaff217b171b32ea2425fe4e59b8c",
    "url": "/img/old/Floppy-Disk.svg"
  },
  {
    "revision": "d197d194ff350fc53077dc5f9dba7cb2",
    "url": "/img/old/favicon-64x64.png"
  },
  {
    "revision": "2151149934d0b229e918aa50a8dd9f4e",
    "url": "/img/old/favicon.svg"
  },
  {
    "revision": "eb79418117a636f5899ab1d7b642a780",
    "url": "/img/old/favicon-16x16.png"
  },
  {
    "revision": "02cd07ba0d732c582f85ac8c364779d3",
    "url": "/img/old/favicon-32x32.png"
  },
  {
    "revision": "cc7ef9a9ff24f6ab32c76c44808d8c81",
    "url": "/img/old/favicon-152x152.png"
  },
  {
    "revision": "ccdad086da02c10eb2a4154ed6e34dcf",
    "url": "/img/old/edward-plans.png"
  },
  {
    "revision": "46c79677df0ee7d8c4e1ba88e412001d",
    "url": "/img/old/favicon-144x144.png"
  },
  {
    "revision": "c5f97cb1b8b890059013821412cedf0c",
    "url": "/img/old/app-screenshot.png"
  },
  {
    "revision": "3bdd4172f514066c84885a124dadeeac",
    "url": "/img/old/edward-outlines.png"
  },
  {
    "revision": "eaf13b721f837da0843767159cca72ad",
    "url": "/img/old/edward-analyze.png"
  },
  {
    "revision": "a92162e1e6b0aeb009322f7402470012",
    "url": "/img/old/Download-Book.svg"
  },
  {
    "revision": "d7a54a779bf7352026e053db7aefd8c6",
    "url": "/img/old/Books.svg"
  },
  {
    "revision": "63807be15f786db6df752c8f63188137",
    "url": "/img/old/Data-Transfer.svg"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/img/modal-logo@2x.png"
  },
  {
    "revision": "825d1ef2f0a157c855e55c3fe65dd694",
    "url": "/img/old/Book-2.svg"
  },
  {
    "revision": "12be2ae19eb1f93956279605f403498f",
    "url": "/img/edward-favicon-32.png"
  },
  {
    "revision": "719c48c86148421ca390286701f707b3",
    "url": "/img/Log-in.png"
  },
  {
    "revision": "ba1c2c5a64baf1f2a40d1f84b20aa54e",
    "url": "/img/Log-in@2x.png"
  },
  {
    "revision": "b18d4df3d403e78c2bfe4dd9c77bd38e",
    "url": "/img/main-logo.png"
  },
  {
    "revision": "e67e1e98d29daf715fe7977dc4ee2ebc",
    "url": "/img/main-logo@2x.png"
  },
  {
    "revision": "15aedca4d4c98a24c1c9aa7d7211a832",
    "url": "/img/icons_workshops-green.png"
  },
  {
    "revision": "1a512567f75e14f71119f684ab9c3d7e",
    "url": "/img/edward-favicon-196.png"
  },
  {
    "revision": "5b33ae66bbe11595b84886df47afb5f9",
    "url": "/img/Web 1920 – App Write (Plan).png"
  },
  {
    "revision": "cc738e32a4d8ca9f0f629306e307ea61",
    "url": "/img/mobile-logo@2x.png"
  },
  {
    "revision": "c0516e1bb9887e56d46e5bed4b91ba4a",
    "url": "/img/icons_outline-white.png"
  },
  {
    "revision": "a323336767255ff753a2a4eb391f4489",
    "url": "/img/icons_plan-green.png"
  },
  {
    "revision": "348eb416472eef84d69425025c480380",
    "url": "/img/icons_plan-white.png"
  },
  {
    "revision": "a62c7a35795181a79b34a5e5de431472",
    "url": "/img/icons_outline-green.png"
  },
  {
    "revision": "937da8d3137ec4f44587b82627285479",
    "url": "/img/mobile-logo.png"
  },
  {
    "revision": "bdf552ee629d4e4e4aac384ef0faf65a",
    "url": "/img/icons_more-white.png"
  },
  {
    "revision": "4de4847b196fb7649ce01a7a0fac3ffa",
    "url": "/img/Upload@2x.png"
  },
  {
    "revision": "6899968cf7139f35f5dd7ac55c0a0ba4",
    "url": "/img/Upload.png"
  },
  {
    "revision": "0c43dfa7a7958afd39815ead1c32747f",
    "url": "/img/edward-favicon-57.png"
  },
  {
    "revision": "5669edeaff1d6510179e99ecc98341d1",
    "url": "/img/Search@2x.png"
  },
  {
    "revision": "fd14371678ff9f00fde7da24428f29e9",
    "url": "/img/Pdf@2x.png"
  },
  {
    "revision": "59770374d53faebb0e53d2968e8115ff",
    "url": "/img/Search.png"
  },
  {
    "revision": "99cae3a0930472446230a1440ca63b3b",
    "url": "/img/form-logo.png"
  },
  {
    "revision": "a7ee511e00a7f5f9888d7015201abb50",
    "url": "/img/form-logo@2x.png"
  },
  {
    "revision": "77f8d5855f7d2e126664e5bdbd3dd733",
    "url": "/img/edward-favicon-96.png"
  },
  {
    "revision": "13d1ab0589e67da34b9426902071f9eb",
    "url": "/img/edward-favicon-76.png"
  },
  {
    "revision": "a75b6f95f52e530f53fc84406c465a71",
    "url": "/img/edward-favicon-512.png"
  },
  {
    "revision": "9f239e8fbaae654816189ff506476960",
    "url": "/img/edward-favicon-192.png"
  },
  {
    "revision": "5e0e5a30b2af795f0b0bef4f2f5e1372",
    "url": "/img/Pdf.png"
  },
  {
    "revision": "77eec39cc1d03006b54dd9ba280784c5",
    "url": "/img/edward-favicon-195.png"
  },
  {
    "revision": "90bbf7cae512f177718197026f01e11e",
    "url": "/img/edward-favicon-16.png"
  },
  {
    "revision": "6fba831ab1b61715eb5d373626d26a4a",
    "url": "/img/edward-favicon-180.png"
  },
  {
    "revision": "165d97b78b2276b1c3f353424c6d0a22",
    "url": "/img/edward-favicon-152.png"
  },
  {
    "revision": "ff69eec62856634b21788e2804568870",
    "url": "/img/Outline@2x.png"
  },
  {
    "revision": "60f0774147dbec254a274290523283d2",
    "url": "/img/edward-favicon-120.png"
  },
  {
    "revision": "74b28d8609de174735c319df4784921b",
    "url": "/img/edward-favicon-144.png"
  },
  {
    "revision": "5b79781e581e80fc58cc3d0fdddf5400",
    "url": "/img/edward-favicon-128.png"
  },
  {
    "revision": "c48182459a0a6fa9525d10bff6e09c32",
    "url": "/img/Outline.png"
  },
  {
    "revision": "63327f5bfb928af6bd432968838b2cd9",
    "url": "/img/Data.png"
  },
  {
    "revision": "525f5cb658c71859b6012cc9054c15fa",
    "url": "/img/Dictionary.png"
  },
  {
    "revision": "aeb1bbd4a5954bd9b0bb4c7358caff17",
    "url": "/img/Interactive-map@2x.png"
  },
  {
    "revision": "2a48829415c20e45208e95dc28f7ee8b",
    "url": "/img/Dictionary@2x.png"
  },
  {
    "revision": "144b43af4287941f6f9c4ad1efe57134",
    "url": "/img/Interactive-map.png"
  },
  {
    "revision": "d37b38c5c09c9c578ffbced0d723d30e",
    "url": "/img/Hero-spots@2x.png"
  },
  {
    "revision": "56837a2db27bc536891f5b9174ba4afb",
    "url": "/img/Hero-spots.png"
  },
  {
    "revision": "c5439818cddcdc7ef782c6e23bef7145",
    "url": "/img/Hero-tablet-01@2x.png"
  },
  {
    "revision": "eb6cea8119e696cf24e1e866642c6591",
    "url": "/img/Hero-tablet-01.png"
  },
  {
    "revision": "cc8f6d4384634d0f0122e662ee9ba25f",
    "url": "/img/Data@2x.png"
  },
  {
    "revision": "6e8061919cc2f38989edb8fd4442d27a",
    "url": "/img/Autosave@2x.png"
  },
  {
    "revision": "3403e43d15879af29b66cf06d578c5f9",
    "url": "/img/Autosave.png"
  },
  {
    "revision": "9703baaed76cd7b86834037b0b1d9a29",
    "url": "/img/Archive@2x.png"
  },
  {
    "revision": "5d5c07f511a191868835df8119185f42",
    "url": "/img/Archive.png"
  },
  {
    "revision": "81d7b8f3c2e566c0d0e5ea33501cfe58",
    "url": "/auth.html"
  },
  {
    "revision": "1dd2ec533393e36fc81b50a19e34af4f",
    "url": "/app.html"
  },
  {
    "revision": "9454475a2f2172ba302d11f7978f009b",
    "url": "/admin.html"
  }
];